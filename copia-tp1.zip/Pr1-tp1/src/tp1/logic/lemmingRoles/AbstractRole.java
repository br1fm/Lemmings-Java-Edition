package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;

public abstract class AbstractRole implements LemmingRole{
	
	private String name;
	private String shortcut;
	private String details;
	
	/**
	 * Constructor para inicializar un rol abstracto.
	 * 
	 * @param name El nombre del rol.
	 * @param shortcut El atajo que representa el rol.
	 * @param details Los detalles descriptivos sobre el rol.
	 */
	AbstractRole(String name, String shortcut, String details){
		this.name = name;
		this.shortcut = shortcut;
		this.details = details;
	}
	
	  @Override
	  public String getName() {
		  return name;
	  }
	  
	  @Override
	  public String getShortcut() {
		  return shortcut;
	  }
	  
	  @Override
	  public String getDetails() {
		  return details;
	  }
	    
	
	/**
	 * La constante que define el valor máximo de caída para el lemming que tiene el rol.
	 */
	protected final int MAX_FALL = 3;
	
	@Override
	public boolean receiveInteraction(GameItem other, Lemming owner) { 
		return other.interactWith(owner);
	}
	
	@Override
    public boolean interactWith(Lemming receiver, Lemming owner) { return false; }
	
	@Override
    public boolean interactWith(Wall wall, Lemming owner) { return false; }
	
	@Override
    public boolean interactWith(ExitDoor door, Lemming owner) { return false; }
    
	@Override
	public void start(Lemming lemming) {
		lemming.setRole(this);
	}
    
    @Override
    public String helpText() {
		return details;
	}
    
    @Override
    public LemmingRole parse(String[] role){
		if(role[1].equalsIgnoreCase(name) || role[1].equalsIgnoreCase(shortcut)){
			return new WalkerRole();
		}
		return null;
	}
    
    public boolean isSolid() {
    	return false;
    }
    
    @Override
    public boolean equals(LemmingRole other_role) {
	       if (this == other_role) return true;
	       if (other_role == null) return false;
	       return (other_role.getName().equals(name) && other_role.getDetails().equals(details) 
	    		   && other_role.getShortcut().equals(shortcut)); 
	 }
	
}
