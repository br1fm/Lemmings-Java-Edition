package tp1.logic;

import java.util.ArrayList;

import java.util.List;

import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.lemmingRoles.LemmingRole;

/**
 * Contenedor de objetos del juego, gestiona los lemmings, las paredes y la puerta de salida.
 */
public class GameObjectContainer {

	private List<GameObject> gameObjects;
	private int dead_lemmings = 0;
	private int freed_lemmings = 0;
	
	/**
	 * Constructor de la clase GameObjectContainer.
	 * Inicializa la lista de objetos.
	 */
	public GameObjectContainer() {
		gameObjects = new ArrayList<>();
	}
	
	public GameObjectContainer(GameObjectContainer other) {
	    // Crear una nueva lista de objetos copiando profundamente cada elemento
	    this.gameObjects = new ArrayList<>();
	    for (GameObject obj : other.gameObjects) {
	        this.gameObjects.add(obj.copy()); 
	    }
	}
	
	/**
	 * Añade un objeto al contenedor.
	 * 
	 * @param o Objeto GameObject a añadir.
	 */
    public void add(GameObject o) {
    	gameObjects.add(o);
    }
	
    /**
	 * Actualiza el estado de todos los objetos en el contenedor,
	 * incluyendo lemmings y paredes, y elimina lemmings muertos o liberados.
	 */
    public void update() {
    	
    	for(GameObject o : gameObjects) {
    		if(o.isAlive()) o.update();
    	}
    	
    	removeObjects();
    }
    
    /**
	 * Devuelve el número de lemmings que están actualmente en el tablero.
	 * 
	 * @return Número de lemmings en el tablero.
	 */
    public int numLemmingsInBoard(int lems_in_board) {
    	return lems_in_board - dead_lemmings - freed_lemmings;
    }
    
    /**
	 * Devuelve el número de lemmings que han muerto.
	 * 
	 * @return Número de lemmings muertos.
	 */
    public int numLemmingsDead() {
    	return dead_lemmings;
    }
    
    /**
	 * Devuelve el número de lemmings que han alcanzado la exit door.
	 * 
	 * @return Número de lemmings que han salido.
	 */
    public int numLemmingsExit() {
    	return freed_lemmings;
    }
    
    /**
	 * Comprueba si hay una wall en la posición especificada.
	 * 
	 * @param comparison Objeto Position a comparar.
	 * @return true si hay una pared en la posición, false en caso contrario.
	 */
    public boolean isSolidAtPos(Position comparison) {
    	
    	int i = 0;
    	boolean stop = false;
    	while(i < gameObjects.size() && !stop) {
    		if(gameObjects.get(i).isInPosition(comparison) && gameObjects.get(i).isSolid()) stop = true;
    		i++;
    	}
    		
    	return (i < gameObjects.size() || stop);
    	
    }
    
    /**
   	 * Comprueba si hay una puerta de salida en la posición especificada.
   	 * 
   	 * @param comparison Objeto Position a comparar.
   	 * @return true si hay una puerta de salida en la posición, false en caso contrario.
   	 */
    public boolean isExitAtPos(Position comparison) {
    	
    	int i = 0;
    	boolean stop = false;
    	while(i < gameObjects.size() && !stop) {
    		if(gameObjects.get(i).isInPosition(comparison) && gameObjects.get(i).isExit()) stop = true;
    		i++;
    	}
    		
    	return (i < gameObjects.size() || stop);
    	
    }
    
    /**
	 * Devuelve una representación del contenido de una posición del tablero.
	 * 
	 * @param col Columna de la posición.
	 * @param row Fila de la posición.
	 * @return Representación en cadena del objeto en la posición.
	 */
    public String positionToString(int col, int row) {
    	
    	StringBuilder res = new StringBuilder();
    	String str = null;
    	Position pos = new Position(col, row);
    	
    	for(GameObject o : gameObjects) {
    		if(o.isInPosition(pos)) {
    			res.append(o);
    		}
    	}
    	
    	str = res.toString();
    	
    	return str;
    }
    
    /**
     * Recibe interacciones de un objeto GameItem y las transmite a los objetos correspondientes
     * dentro del contenedor que estén vivos.
     * 
     * @param obj Objeto del tipo GameItem con el que interactuar.
     * @return true si alguna interacción fue procesada correctamente, false en caso contrario.
     */
    public boolean receiveInteractionsFrom(GameItem obj){
    	
    	int i = 0;
    	boolean stop = false;
    	while(i < gameObjects.size() && !stop) {
    		if(gameObjects.get(i).isAlive()) { 
    			if(gameObjects.get(i).receiveInteraction(obj)) stop = true;
    		}
    		i++;
    	}
    	
    	return (i < gameObjects.size());
    	
    }
    
    /**
     * Elimina de la lista de objetos aquellos que no están vivos (muertos) o han sido liberados.
     * También actualiza los contadores de lemmings muertos y liberados.
     */
    public void removeObjects() {
        List<GameObject> toRemove = new ArrayList<>();
        for (GameObject o : gameObjects) {
            if (!o.isAlive()) {
                toRemove.add(o);
                if(!o.isSolid()) dead_lemmings++;
            } else if (o.isFreed()) {
                toRemove.add(o);
                freed_lemmings++;
            }
        }
        gameObjects.removeAll(toRemove);
    }
    
    void setFreedLemmings(int numFreedLemmings) {
    	this.freed_lemmings = numFreedLemmings;
    }
    
    void setDeadlemmings(int numDeadLemmings) {
    	this.dead_lemmings = numDeadLemmings;
    }

    /**
     * Asigna un rol a un lemming en una posición específica del tablero.
     * 
     * @param role El rol a asignar al lemming.
     * @param comparison La posición del lemming al que se le asignará el rol.
     * @return true si el rol fue asignado exitosamente, false en caso contrario.
     */
	public boolean setRole(LemmingRole role, Position comparison) {
		int i = 0;
    	boolean stop = false;
    	while(i < gameObjects.size() && !stop) {
    		if(gameObjects.get(i).isInPosition(comparison)) {
    			if(gameObjects.get(i).setRole(role)) stop = true;
    		}
    		i++;
    	}
    		
    	return (stop);
	}
    
}
